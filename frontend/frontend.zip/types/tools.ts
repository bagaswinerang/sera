import type { Comparison } from "./comparison";

export type ToolError = { error: string; status?: number };

// tool-lookup_glossary
export type GlossaryOutput =
  | {
      found: true;
      entries: {
        term: string;
        simple: string;
        detail: string;
        example: string;
      }[];
    }
  | { found: false; hint: string };

// tool-get_company_report: render DEFENSIF, semua field opsional
export type CompanyReportOutput =
  | (Record<string, unknown> & {
      symbol?: string;
      company_name?: string;
      overview?: {
        sub_sector?: string;
        market_cap?: number;
        latest_close_date?: string;
      };
      valuation?: { forward_pe?: number };
      dividend?: {
        yield_ttm?: number;
        dividend_ttm?: number;
        payout_ratio?: number;
      };
      financials?: { yoy_quarter_earnings_growth?: number };
    })
  | ToolError;

// tool-get_quarterly_financials
export type QuarterlyOutput =
  | {
      quarters: {
        date: string;
        revenue: number | null;
        earnings: number | null;
        earnings_change_vs_prev_quarter: number | null;
      }[];
      earnings_stability: { quarters_used: number; cv: number } | null;
      sector_metrics_latest: Record<string, number> | null;
      note: string;
    }
  | ToolError;

// tool-screen_companies
export type ScreenerOutput =
  | {
      results: {
        symbol: string;
        company_name: string;
        query_values?: Record<string, unknown>;
      }[];
      total_count?: number;
      interpreted_as?: unknown;
      note?: string;
    }
  | ToolError;

// tool-compare_companies
export type CompareOutput = Comparison | ToolError;
