"use client";

import Link from "next/link";
import { ThemeToggle } from "./theme-toggle";
import { Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

export function Header() {
  const [logoSrc, setLogoSrc] = useState<string>("/logo-trans.webp");

  useEffect(() => {
    fetch("/api/set-active-logo")
      .then((res) => res.json())
      .then((data) => {
        if (data?.activeMeta?.transUrl) {
          setLogoSrc(data.activeMeta.transUrl);
        } else if (data?.activeMeta?.iconUrl) {
          setLogoSrc(data.activeMeta.iconUrl);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <header className="sera-glass border-b border-border/40 sticky top-0 z-50">
      <div className="mx-auto flex h-14 w-full max-w-[760px] items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2.5 group">
          {/* Minimalist, Clean Logo Container (No loud neon lighting) */}
          <div className="w-8 h-8 rounded-lg bg-card/70 border border-border/70 flex items-center justify-center p-1 transition-all duration-200 group-hover:border-primary/40 group-hover:bg-card">
            <img
              src={logoSrc}
              alt="Sera Logo"
              className="w-full h-full object-contain"
              onError={(e) => {
                (e.target as HTMLElement).style.display = "none";
              }}
            />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-bold tracking-tight leading-none text-foreground group-hover:text-primary transition-colors">
              Sera
            </span>
            <span className="text-[10px] font-medium text-muted-foreground leading-none mt-0.5">
              AI Saham Indonesia
            </span>
          </div>
        </Link>

        <div className="flex items-center gap-2">
          <Link
            href="/logo"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-secondary/80 hover:bg-secondary text-foreground/80 hover:text-foreground border border-border/60 transition-all hover:scale-[1.01]"
            title="Lihat 3 Konsep Logo & Filosofi"
          >
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span>Pilihan Logo</span>
          </Link>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
