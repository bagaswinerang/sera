import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const outputDir = path.resolve(__dirname, '../public/logos');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// ─────────────────────────────────────────────────────────────
// LOGO 1 (NEW FUSION: COMBINATION OF IDE 2 & IDE 3)
// "THE QUANTUM CONTINUUM" (Candlestick Bars + Monoline S-Loop)
// ─────────────────────────────────────────────────────────────
const svgLogo1Icon = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="l1-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#121318" />
      <stop offset="100%" stop-color="#07080B" />
    </linearGradient>
    <linearGradient id="l1-flow-grad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#DC2626" />
      <stop offset="45%" stop-color="#FF5100" />
      <stop offset="100%" stop-color="#FFA600" />
    </linearGradient>
    <linearGradient id="l1-wick-orange" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFA600" />
      <stop offset="100%" stop-color="#FF5100" />
    </linearGradient>
    <linearGradient id="l1-wick-red" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FF334B" />
      <stop offset="100%" stop-color="#991B1B" />
    </linearGradient>
    <linearGradient id="l1-border-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="rgba(255, 166, 0, 0.25)" />
      <stop offset="100%" stop-color="rgba(220, 38, 38, 0.18)" />
    </linearGradient>
    <filter id="l1-subtle-glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="8" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>

  <!-- Clean Minimalist Background Container -->
  <rect width="512" height="512" rx="112" fill="url(#l1-bg)" />
  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="url(#l1-border-grad)" stroke-width="2" />

  <!-- IDE 2 ELEMENT: CANDLESTICK VERTICAL WICKS (AXIS OF PRECISION) -->
  <!-- Upper Candlestick Wick (Bullish Apex) -->
  <line x1="334" y1="84" x2="334" y2="240" stroke="url(#l1-wick-orange)" stroke-width="7" stroke-linecap="round" opacity="0.85" />
  <!-- Lower Candlestick Wick (Risk Foundation) -->
  <line x1="178" y1="272" x2="178" y2="428" stroke="url(#l1-wick-red)" stroke-width="7" stroke-linecap="round" opacity="0.85" />

  <!-- COMBINED FUSION: FLUID MONOLINE S-CURVE (IDE 3) INTEGRATING CANDLESTICK PILLARS (IDE 2) -->
  <!-- Mathematical smooth continuous ribbon flowing through both candlestick bodies -->
  <path d="M 334 142
           C 334 114, 296 98, 256 98
           C 192 98, 154 138, 154 194
           C 154 262, 226 284, 286 304
           C 338 322, 358 348, 358 392
           C 358 438, 320 468, 256 468
           C 204 468, 178 442, 178 370"
        fill="none"
        stroke="url(#l1-flow-grad)"
        stroke-width="48"
        stroke-linecap="round"
        stroke-linejoin="round" />

  <!-- IDE 2 ELEMENT: CANDLESTICK SOLID BODY ACCENTS -->
  <!-- Upper Candlestick Pillar Solid Body (Orange Core) -->
  <rect x="312" y="132" width="44" height="84" rx="12" fill="#FFA600" opacity="0.95" />
  
  <!-- Lower Candlestick Pillar Solid Body (Red Core) -->
  <rect x="156" y="296" width="44" height="84" rx="12" fill="#DC2626" opacity="0.95" />

  <!-- Focal Quantum AI Node (Harmonic Center Pulse) -->
  <circle cx="256" cy="256" r="11" fill="#FFFFFF" />
  <circle cx="256" cy="256" r="22" fill="none" stroke="#FF5100" stroke-width="2.5" opacity="0.5" />
</svg>
`;

const svgLogo1Transparent = svgLogo1Icon.replace(
  '<rect width="512" height="512" rx="112" fill="url(#l1-bg)" />\n  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="url(#l1-border-grad)" stroke-width="2" />',
  '<!-- Transparent Background -->'
);

const svgLogo1Full = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 400" width="1200" height="400">
  <defs>
    <linearGradient id="l1-bg-full" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0E0F14" />
      <stop offset="100%" stop-color="#070709" />
    </linearGradient>
    <linearGradient id="l1-flow-f" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#DC2626" />
      <stop offset="50%" stop-color="#FF5100" />
      <stop offset="100%" stop-color="#FFA600" />
    </linearGradient>
    <linearGradient id="l1-text-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF" />
      <stop offset="100%" stop-color="#F1F5F9" />
    </linearGradient>
  </defs>

  <rect width="1200" height="400" rx="32" fill="url(#l1-bg-full)" />
  <rect width="1196" height="396" x="2" y="2" rx="30" fill="none" stroke="rgba(255, 100, 0, 0.12)" stroke-width="2" />

  <!-- Logo Mark -->
  <g transform="translate(60, 36) scale(0.64)">
    <line x1="334" y1="84" x2="334" y2="240" stroke="#FFA600" stroke-width="7" stroke-linecap="round" opacity="0.85" />
    <line x1="178" y1="272" x2="178" y2="428" stroke="#DC2626" stroke-width="7" stroke-linecap="round" opacity="0.85" />
    
    <path d="M 334 142
             C 334 114, 296 98, 256 98
             C 192 98, 154 138, 154 194
             C 154 262, 226 284, 286 304
             C 338 322, 358 348, 358 392
             C 358 438, 320 468, 256 468
             C 204 468, 178 442, 178 370"
          fill="none"
          stroke="url(#l1-flow-f)"
          stroke-width="48"
          stroke-linecap="round"
          stroke-linejoin="round" />

    <rect x="312" y="132" width="44" height="84" rx="12" fill="#FFA600" opacity="0.95" />
    <rect x="156" y="296" width="44" height="84" rx="12" fill="#DC2626" opacity="0.95" />

    <circle cx="256" cy="256" r="11" fill="#FFFFFF" />
    <circle cx="256" cy="256" r="22" fill="none" stroke="#FF5100" stroke-width="2.5" opacity="0.5" />
  </g>

  <!-- Typography -->
  <text x="440" y="215" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="140" fill="url(#l1-text-grad)" letter-spacing="4">SERA</text>
  <rect x="888" y="122" width="22" height="22" rx="6" fill="#FF5100" />
  
  <text x="444" y="275" font-family="system-ui, -apple-system, sans-serif" font-weight="700" font-size="28" fill="#FF7700" letter-spacing="8">AI SAHAM INDONESIA</text>
  <rect x="444" y="298" width="580" height="2" fill="url(#l1-flow-f)" opacity="0.6" />
  <text x="444" y="332" font-family="system-ui, -apple-system, sans-serif" font-weight="500" font-size="20" fill="#94A3B8" letter-spacing="3">CANDLESTICK CONTINUUM • QUANTUM PRECISION</text>
</svg>
`;

// ─────────────────────────────────────────────────────────────
// LOGO 2: THE QUANTUM CANDLESTICK (DIJAGA TETAP SEPERTI PERMINTAAN USER)
// ─────────────────────────────────────────────────────────────
const svgLogo2Icon = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="l2-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#111218" />
      <stop offset="100%" stop-color="#07080B" />
    </linearGradient>
    <linearGradient id="l2-bar1" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FFA100" />
      <stop offset="100%" stop-color="#FF5100" />
    </linearGradient>
    <linearGradient id="l2-bar2" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FF5100" />
      <stop offset="100%" stop-color="#E11D48" />
    </linearGradient>
    <linearGradient id="l2-bar3" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#E11D48" />
      <stop offset="100%" stop-color="#9F1239" />
    </linearGradient>
    <linearGradient id="l2-glow-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF6A00" stop-opacity="0.3" />
      <stop offset="100%" stop-color="#E11D48" stop-opacity="0" />
    </linearGradient>
  </defs>

  <!-- Background Base -->
  <rect width="512" height="512" rx="112" fill="url(#l2-bg)" />
  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="rgba(255, 60, 0, 0.2)" stroke-width="2" />

  <!-- Shield Hex Outline Glow -->
  <polygon points="256,60 416,150 416,362 256,452 96,362 96,150" fill="url(#l2-glow-grad)" stroke="#FF4D00" stroke-width="3" stroke-opacity="0.4" stroke-dasharray="12 6" />

  <!-- Candlestick Wick Vertical Guides -->
  <line x1="184" y1="120" x2="184" y2="340" stroke="#FF5100" stroke-width="4" stroke-linecap="round" opacity="0.6" />
  <line x1="256" y1="90" x2="256" y2="420" stroke="#FFA100" stroke-width="5" stroke-linecap="round" opacity="0.8" />
  <line x1="328" y1="170" x2="328" y2="390" stroke="#E11D48" stroke-width="4" stroke-linecap="round" opacity="0.6" />

  <!-- Candlestick Blocks Interlocking into S-Formation -->
  <rect x="226" y="130" width="132" height="48" rx="10" fill="url(#l2-bar1)" transform="rotate(-15 292 154)" />
  <rect x="156" y="160" width="56" height="110" rx="14" fill="url(#l2-bar1)" />
  <rect x="176" y="232" width="160" height="48" rx="12" fill="url(#l2-bar2)" transform="rotate(-25 256 256)" />
  <rect x="300" y="242" width="56" height="110" rx="14" fill="url(#l2-bar2)" />
  <rect x="154" y="334" width="132" height="48" rx="10" fill="url(#l2-bar3)" transform="rotate(-15 220 358)" />

  <circle cx="256" cy="90" r="10" fill="#FFC700" />
  <circle cx="256" cy="90" r="18" fill="none" stroke="#FFC700" stroke-width="2" opacity="0.5" />
  <circle cx="184" cy="120" r="7" fill="#FF5100" />
  <circle cx="328" cy="390" r="7" fill="#E11D48" />
  <circle cx="256" cy="256" r="8" fill="#FFFFFF" />
</svg>
`;

const svgLogo2Transparent = svgLogo2Icon.replace(
  '<rect width="512" height="512" rx="112" fill="url(#l2-bg)" />\n  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="rgba(255, 60, 0, 0.2)" stroke-width="2" />',
  '<!-- Transparent Background -->'
);

const svgLogo2Full = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 400" width="1200" height="400">
  <defs>
    <linearGradient id="l2-bg-full" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0E0F14" />
      <stop offset="100%" stop-color="#060709" />
    </linearGradient>
    <linearGradient id="l2-grad-main" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF9D00" />
      <stop offset="50%" stop-color="#FF4D00" />
      <stop offset="100%" stop-color="#E11D48" />
    </linearGradient>
    <linearGradient id="l2-text-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF" />
      <stop offset="100%" stop-color="#F1F5F9" />
    </linearGradient>
  </defs>

  <rect width="1200" height="400" rx="32" fill="url(#l2-bg-full)" />
  <rect width="1196" height="396" x="2" y="2" rx="30" fill="none" stroke="rgba(255, 77, 0, 0.16)" stroke-width="2" />

  <g transform="translate(60, 35) scale(0.64)">
    <polygon points="256,60 416,150 416,362 256,452 96,362 96,150" fill="rgba(255, 77, 0, 0.08)" stroke="#FF4D00" stroke-width="3" stroke-opacity="0.4" stroke-dasharray="12 6" />
    <line x1="184" y1="120" x2="184" y2="340" stroke="#FF5100" stroke-width="4" stroke-linecap="round" opacity="0.6" />
    <line x1="256" y1="90" x2="256" y2="420" stroke="#FFA100" stroke-width="5" stroke-linecap="round" opacity="0.8" />
    <line x1="328" y1="170" x2="328" y2="390" stroke="#E11D48" stroke-width="4" stroke-linecap="round" opacity="0.6" />
    
    <rect x="226" y="130" width="132" height="48" rx="10" fill="#FFA100" transform="rotate(-15 292 154)" />
    <rect x="156" y="160" width="56" height="110" rx="14" fill="#FFA100" />
    <rect x="176" y="232" width="160" height="48" rx="12" fill="#FF5100" transform="rotate(-25 256 256)" />
    <rect x="300" y="242" width="56" height="110" rx="14" fill="#E11D48" />
    <rect x="154" y="334" width="132" height="48" rx="10" fill="#BE123C" transform="rotate(-15 220 358)" />

    <circle cx="256" cy="90" r="10" fill="#FFC700" />
    <circle cx="184" cy="120" r="7" fill="#FF5100" />
    <circle cx="328" cy="390" r="7" fill="#E11D48" />
    <circle cx="256" cy="256" r="8" fill="#FFFFFF" />
  </g>

  <text x="440" y="215" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="140" fill="url(#l2-text-grad)" letter-spacing="4">SERA</text>
  <rect x="885" y="120" width="24" height="24" rx="6" fill="#FF4D00" />
  
  <text x="444" y="275" font-family="system-ui, -apple-system, sans-serif" font-weight="700" font-size="28" fill="#FF6A00" letter-spacing="8">AI SAHAM INDONESIA</text>
  <rect x="444" y="298" width="580" height="2" fill="url(#l2-grad-main)" opacity="0.6" />
  <text x="444" y="332" font-family="system-ui, -apple-system, sans-serif" font-weight="500" font-size="20" fill="#94A3B8" letter-spacing="3">CANDLESTICK ANALYTICS • HEDGE ENGINE</text>
</svg>
`;

// ─────────────────────────────────────────────────────────────
// LOGO 3: THE CONTINUUM S (Monoline Twin Arc & Fibonacci Loop)
// ─────────────────────────────────────────────────────────────
const svgLogo3Icon = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="l3-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#111116" />
      <stop offset="100%" stop-color="#08080B" />
    </linearGradient>
    <linearGradient id="l3-loop-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFA600" />
      <stop offset="48%" stop-color="#FF5100" />
      <stop offset="100%" stop-color="#E11D48" />
    </linearGradient>
    <linearGradient id="l3-border-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="rgba(255, 166, 0, 0.22)" />
      <stop offset="100%" stop-color="rgba(225, 29, 72, 0.15)" />
    </linearGradient>
  </defs>

  <!-- Clean Matte Background -->
  <rect width="512" height="512" rx="112" fill="url(#l3-bg)" />
  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="url(#l3-border-grad)" stroke-width="2" />

  <!-- ULTRA-MINIMALIST MONOLINE S (CONTINUUM DUAL ARC) -->
  <path d="M 346 172
           C 346 128, 308 96, 256 96
           C 198 96, 154 140, 154 198
           C 154 266, 224 286, 276 304
           C 324 320, 358 344, 358 392
           C 358 450, 310 490, 256 490
           C 196 490, 154 452, 154 402"
        fill="none"
        stroke="url(#l3-loop-grad)"
        stroke-width="52"
        stroke-linecap="round"
        stroke-linejoin="round"
        transform="translate(0, -38) scale(1, 0.94) translate(0, 16)" />

  <circle cx="346" cy="142" r="14" fill="#FFA600" />
  <circle cx="154" cy="370" r="12" fill="#E11D48" />
</svg>
`;

const svgLogo3Transparent = svgLogo3Icon.replace(
  '<rect width="512" height="512" rx="112" fill="url(#l3-bg)" />\n  <rect width="508" height="508" x="2" y="2" rx="110" fill="none" stroke="url(#l3-border-grad)" stroke-width="2" />',
  '<!-- Transparent Background -->'
);

const svgLogo3Full = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 400" width="1200" height="400">
  <defs>
    <linearGradient id="l3-bg-full" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#0E0F14" />
      <stop offset="100%" stop-color="#070709" />
    </linearGradient>
    <linearGradient id="l3-grad-full" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFA600" />
      <stop offset="50%" stop-color="#FF5100" />
      <stop offset="100%" stop-color="#E11D48" />
    </linearGradient>
    <linearGradient id="l3-text-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF" />
      <stop offset="100%" stop-color="#F1F5F9" />
    </linearGradient>
  </defs>

  <rect width="1200" height="400" rx="32" fill="url(#l3-bg-full)" />
  <rect width="1196" height="396" x="2" y="2" rx="30" fill="none" stroke="rgba(255, 120, 0, 0.12)" stroke-width="2" />

  <!-- Logo Mark -->
  <g transform="translate(60, 35) scale(0.64)">
    <path d="M 346 172
             C 346 128, 308 96, 256 96
             C 198 96, 154 140, 154 198
             C 154 266, 224 286, 276 304
             C 324 320, 358 344, 358 392
             C 358 450, 310 490, 256 490
             C 196 490, 154 452, 154 402"
          fill="none"
          stroke="url(#l3-grad-full)"
          stroke-width="52"
          stroke-linecap="round"
          stroke-linejoin="round"
          transform="translate(0, -38) scale(1, 0.94) translate(0, 16)" />
    <circle cx="346" cy="142" r="14" fill="#FFA600" />
    <circle cx="154" cy="370" r="12" fill="#E11D48" />
  </g>

  <!-- Typography -->
  <text x="440" y="215" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="140" fill="url(#l3-text-grad)" letter-spacing="4">SERA</text>
  <circle cx="895" cy="130" r="14" fill="#E11D48" />
  
  <text x="444" y="275" font-family="system-ui, -apple-system, sans-serif" font-weight="700" font-size="28" fill="#FF7700" letter-spacing="8">AI SAHAM INDONESIA</text>
  <rect x="444" y="298" width="580" height="2" fill="url(#l3-grad-full)" opacity="0.6" />
  <text x="444" y="332" font-family="system-ui, -apple-system, sans-serif" font-weight="500" font-size="20" fill="#94A3B8" letter-spacing="3">MONOLINE CONTINUUM • COMPOUNDING ALPHA</text>
</svg>
`;

const logos = [
  {
    id: 1,
    name: 'sera-concept-1-neural-bull', // File mapping kept consistent
    svgIcon: svgLogo1Icon,
    svgTrans: svgLogo1Transparent,
    svgFull: svgLogo1Full
  },
  {
    id: 2,
    name: 'sera-concept-2-quantum-candlestick',
    svgIcon: svgLogo2Icon,
    svgTrans: svgLogo2Transparent,
    svgFull: svgLogo2Full
  },
  {
    id: 3,
    name: 'sera-concept-3-phoenix-crest',
    svgIcon: svgLogo3Icon,
    svgTrans: svgLogo3Transparent,
    svgFull: svgLogo3Full
  }
];

async function generateAll() {
  console.log('Rendering logos into SVG, PNG, and WebP (Fusing Ide 2 & 3 into Ide 1)...');

  for (const item of logos) {
    // 1. Save SVGs
    const iconSvgPath = path.join(outputDir, `${item.name}-icon.svg`);
    const transSvgPath = path.join(outputDir, `${item.name}-transparent.svg`);
    const fullSvgPath = path.join(outputDir, `${item.name}-full.svg`);

    fs.writeFileSync(iconSvgPath, item.svgIcon.trim());
    fs.writeFileSync(transSvgPath, item.svgTrans.trim());
    fs.writeFileSync(fullSvgPath, item.svgFull.trim());

    // 2. Render Icon PNG (512x512 and 1024x1024)
    await sharp(Buffer.from(item.svgIcon))
      .resize(512, 512)
      .png({ quality: 100 })
      .toFile(path.join(outputDir, `${item.name}-icon.png`));

    await sharp(Buffer.from(item.svgIcon))
      .resize(1024, 1024)
      .png({ quality: 100 })
      .toFile(path.join(outputDir, `${item.name}-icon-1024.png`));

    // 3. Render Icon WebP (512x512 and 1024x1024)
    await sharp(Buffer.from(item.svgIcon))
      .resize(512, 512)
      .webp({ quality: 95, lossless: false })
      .toFile(path.join(outputDir, `${item.name}-icon.webp`));

    await sharp(Buffer.from(item.svgIcon))
      .resize(1024, 1024)
      .webp({ quality: 95, lossless: false })
      .toFile(path.join(outputDir, `${item.name}-icon-1024.webp`));

    // 4. Render Transparent PNG & WebP
    await sharp(Buffer.from(item.svgTrans))
      .resize(512, 512)
      .png({ quality: 100 })
      .toFile(path.join(outputDir, `${item.name}-trans.png`));

    await sharp(Buffer.from(item.svgTrans))
      .resize(512, 512)
      .webp({ quality: 95, lossless: false })
      .toFile(path.join(outputDir, `${item.name}-trans.webp`));

    // 5. Render Full Logo PNG & WebP (1200x400)
    await sharp(Buffer.from(item.svgFull))
      .resize(1200, 400)
      .png({ quality: 100 })
      .toFile(path.join(outputDir, `${item.name}-full.png`));

    await sharp(Buffer.from(item.svgFull))
      .resize(1200, 400)
      .webp({ quality: 95, lossless: false })
      .toFile(path.join(outputDir, `${item.name}-full.webp`));

    console.log(`Generated all formats for ${item.name}!`);
  }

  // Sync active logo in public/
  const activeMetaPath = path.resolve(__dirname, '../public/active-logo.json');
  let activeId = 1;
  if (fs.existsSync(activeMetaPath)) {
    try {
      const currentMeta = JSON.parse(fs.readFileSync(activeMetaPath, 'utf-8'));
      activeId = currentMeta.activeId || 1;
    } catch {}
  }

  const activeItem = logos.find(l => l.id === activeId) || logos[0];
  const publicDir = path.resolve(__dirname, '../public');
  fs.copyFileSync(path.join(outputDir, `${activeItem.name}-icon.png`), path.join(publicDir, 'logo-icon.png'));
  fs.copyFileSync(path.join(outputDir, `${activeItem.name}-icon.webp`), path.join(publicDir, 'logo-icon.webp'));
  fs.copyFileSync(path.join(outputDir, `${activeItem.name}-full.png`), path.join(publicDir, 'logo-full.png'));
  fs.copyFileSync(path.join(outputDir, `${activeItem.name}-full.webp`), path.join(publicDir, 'logo-full.webp'));

  console.log('FUSION LOGO 1 GENERATED & SYNCED IN public/logos/');
}

generateAll().catch(err => {
  console.error('Error generating logos:', err);
  process.exit(1);
});
