import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function POST(req: Request) {
  try {
    const { conceptId } = await req.json();
    if (!conceptId || ![1, 2, 3].includes(Number(conceptId))) {
      return NextResponse.json(
        { error: "Invalid concept ID. Expected 1, 2, or 3." },
        { status: 400 }
      );
    }

    const publicDir = path.resolve(process.cwd(), "public");
    const logosDir = path.resolve(publicDir, "logos");

    const mapping: Record<number, { name: string; title: string }> = {
      1: { name: "sera-concept-1-neural-bull", title: "The Quantum Continuum (Candlestick + Monoline S)" },
      2: { name: "sera-concept-2-quantum-candlestick", title: "The Quantum Candlestick" },
      3: { name: "sera-concept-3-phoenix-crest", title: "The Continuum S (Monoline Loop)" },
    };

    const target = mapping[Number(conceptId)];

    // Copy selected files to standard root public assets
    const filesToCopy = [
      { src: `${target.name}-icon.png`, dest: "logo-icon.png" },
      { src: `${target.name}-icon.webp`, dest: "logo-icon.webp" },
      { src: `${target.name}-icon.svg`, dest: "logo-icon.svg" },
      { src: `${target.name}-full.png`, dest: "logo-full.png" },
      { src: `${target.name}-full.webp`, dest: "logo-full.webp" },
      { src: `${target.name}-full.svg`, dest: "logo-full.svg" },
      { src: `${target.name}-trans.png`, dest: "logo-trans.png" },
      { src: `${target.name}-trans.webp`, dest: "logo-trans.webp" },
    ];

    for (const file of filesToCopy) {
      const srcPath = path.join(logosDir, file.src);
      const destPath = path.join(publicDir, file.dest);
      if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, destPath);
      }
    }

    // Save active logo meta
    const activeMeta = {
      activeId: Number(conceptId),
      conceptName: target.name,
      title: target.title,
      updatedAt: new Date().toISOString(),
      iconUrl: "/logo-trans.webp",
      transUrl: "/logo-trans.webp",
      boxedIconUrl: "/logo-icon.png",
      fullUrl: "/logo-full.png",
      svgIconUrl: "/logo-icon.svg",
      svgFullUrl: "/logo-full.svg",
    };

    fs.writeFileSync(
      path.join(publicDir, "active-logo.json"),
      JSON.stringify(activeMeta, null, 2)
    );

    return NextResponse.json({
      success: true,
      message: `Logo Konsep ${conceptId} (${target.title}) berhasil diterapkan ke web!`,
      activeMeta,
    });
  } catch (error) {
    console.error("Error setting active logo:", error);
    return NextResponse.json(
      { error: "Gagal menerapkan logo." },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const publicDir = path.resolve(process.cwd(), "public");
    const metaPath = path.join(publicDir, "active-logo.json");
    if (fs.existsSync(metaPath)) {
      const data = JSON.parse(fs.readFileSync(metaPath, "utf-8"));
      return NextResponse.json({ activeMeta: data });
    }
    return NextResponse.json({ activeMeta: null });
  } catch {
    return NextResponse.json({ activeMeta: null });
  }
}
