"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { 
  ArrowLeft, 
  Download, 
  Check, 
  CheckCircle2, 
  Sparkles, 
  Flame, 
  Cpu, 
  TrendingUp, 
  ShieldCheck, 
  Layers, 
  Palette, 
  Eye, 
  Laptop, 
  Smartphone, 
  FileCode, 
  ExternalLink,
  ChevronRight,
  Zap,
  Activity
} from "lucide-react";

interface ConceptData {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  coreMetaphor: string;
  badge: string;
  palette: {
    black: { name: string; hex: string; role: string };
    orange: { name: string; hex: string; role: string };
    red: { name: string; hex: string; role: string };
  };
  philosophy: {
    visualShape: string;
    colors: string;
    aiAndStockSynergy: string;
    relevanceToIndonesianMarket: string;
  };
  uiuxImpact: {
    primaryAtmosphere: string;
    accentUsage: string;
    componentVibe: string;
  };
  files: {
    iconPng: string;
    iconPng1024: string;
    iconWebp: string;
    iconWebp1024: string;
    transPng: string;
    transWebp: string;
    fullPng: string;
    fullWebp: string;
    iconSvg: string;
    fullSvg: string;
  };
}

const CONCEPTS: ConceptData[] = [
  {
    id: 1,
    slug: "sera-concept-1-neural-bull",
    name: "The Quantum Continuum",
    tagline: "Fusion of Technical Candlestick & Fluid Monoline S",
    coreMetaphor: "Sumbu Candlestick Teknis (Ide 2) + Pita Kurva Monoline S (Ide 3)",
    badge: "Fusion Minimalis (Ide 2 + 3)",
    palette: {
      black: { name: "Obsidian Slate", hex: "#121318", role: "Kanvas dark cockpit yang tenang dan stabil" },
      orange: { name: "Cyber Amber", hex: "#FFA600", role: "Pilar candlestick atas, akselerasi cuan, sinyal buy cerdas" },
      red: { name: "Ruby Baseline", hex: "#DC2626", role: "Pilar candlestick bawah, batas risiko, proteksi modal" }
    },
    philosophy: {
      visualShape:
        "Merupakan sintesis cerdas antara presisi teknis Candlestick (Ide 2) dan keanggunan kurva Monoline S (Ide 3). Logo ini mengambil dua pilar candlestick vertikal dengan garis sumbu (wicks) tajam pada puncak atas dan lembah bawah, yang kemudian dihubungkan secara harmonis oleh satu pita kurva kontinu berketebalan proporsional. Di titik temu pusat, terdapat focal node kuantum yang melambangkan inti kecerdasan buatan SERA.",
      colors:
        "Transisi warna mulus tanpa jeda dari Merah Ruby (#DC2626) di pilar bawah (fondasi proteksi risiko), mengalir melalui Oranye Neon (#FF5100), menuju Kuning Amber (#FFA600) di pilar atas (pencapaian target harga). Berlatar belakang Hitam Obsidian (#121318) yang elegan.",
      aiAndStockSynergy:
        "Candlestick melambangkan dunia nyata trading saham Indonesia (IHSG, price action, volume), sedangkan kurva kontinu S melambangkan fleksibilitas algoritma AI dan siklus modal yang terus berlipat ganda (compounding alpha). Menggabungkan ketegasan kalkulasi matematis dengan keanggunan teknologi masa depan.",
      relevanceToIndonesianMarket:
        "Sangat relevan karena investor saham Indonesia membutuhkan kejelasan teknikal (bisa langsung melihat candlestick saham) sekaligus jaminan bahwa ada kecerdasan AI yang mengalir mulus menjaga portofolio mereka dari volatilitas pasar."
    },
    uiuxImpact: {
      primaryAtmosphere: "Modern Quantitative Cockpit: perpaduan ketegasan chart teknikal dengan kehalusan antarmuka fintech kelas dunia.",
      accentUsage: "Oranye terang untuk pilar metrik bullish dan tombol beli; Merah ruby untuk batas proteksi risiko; node putih bercahaya untuk indikator AI live.",
      componentVibe: "Minimalis, presisi tinggi (balanced grid), sudut membulat modern, dan zero visual noise."
    },
    files: {
      iconPng: "/logos/sera-concept-1-neural-bull-icon.png",
      iconPng1024: "/logos/sera-concept-1-neural-bull-icon-1024.png",
      iconWebp: "/logos/sera-concept-1-neural-bull-icon.webp",
      iconWebp1024: "/logos/sera-concept-1-neural-bull-icon-1024.webp",
      transPng: "/logos/sera-concept-1-neural-bull-trans.png",
      transWebp: "/logos/sera-concept-1-neural-bull-trans.webp",
      fullPng: "/logos/sera-concept-1-neural-bull-full.png",
      fullWebp: "/logos/sera-concept-1-neural-bull-full.webp",
      iconSvg: "/logos/sera-concept-1-neural-bull-icon.svg",
      fullSvg: "/logos/sera-concept-1-neural-bull-full.svg"
    }
  },
  {
    id: 2,
    slug: "sera-concept-2-quantum-candlestick",
    name: "The Quantum Candlestick",
    tagline: "Algorithmic Precision & Quantitative Shield",
    coreMetaphor: "Batang Candlestick Teknis + Perisai Heksagonal S-Matrix",
    badge: "Presisi & Algoritmik",
    palette: {
      black: { name: "Obsidian Tech", hex: "#0B0C10", role: "Keamanan institusional, kedalaman komputasi kuantitatif" },
      orange: { name: "Cyber Orange", hex: "#FF6A00", role: "Konektivitas sinyal, data pipeline real-time" },
      red: { name: "Ruby Precision", hex: "#DC2626", role: "Hedge risk barrier, presisi stop order, analisis teknikal murni" }
    },
    philosophy: {
      visualShape:
        "Siluet heksagonal perisai keamanan yang di dalamnya tersusun 3 bar candlestick berstruktur geometris dengan sumbu vertikal (wicks), yang secara harmonis membentuk huruf 'S' isometrik. Titik pusat di tengah bertindak sebagai focal core yang memancarkan sinyal kalkulasi AI berbasis probabilitas matematika.",
      colors:
        "Harmonisasi warna Oranye Cyber (#FF6A00) dan Merah Ruby (#DC2626) dengan garis bantu teknis berlatar belakang Hitam Gelap (#0B0C10). Menghadirkan kesan disiplin analitik, hedging risiko yang terlindungi, dan kalkulasi matematis tanpa bias emosional.",
      aiAndStockSynergy:
        "Candlestick adalah bahasa teknikal fundamental dari setiap investor saham di dunia. Dengan membungkus candlestick dalam modul sirkuit cerdas huruf 'S', SERA diposisikan sebagai platform AI kuantitatif yang mampu membaca formasi grafik, volume spike, dan support-resistance secara instan.",
      relevanceToIndonesianMarket:
        "Banyak investor saham pemula di Indonesia sering terjebak 'FOMO' atau rumor spekulatif. Konsep ini memposisikan SERA sebagai pelindung portofolio (shield) berbasis data chart yang objektif, transparan, dan teruji secara algoritma kuantitatif.",
    },
    uiuxImpact: {
      primaryAtmosphere: "Data-dense financial terminal bergaya Bloomberg/TradingView masa depan yang rapi dan terukur.",
      accentUsage: "Border heksagonal halus, visualisasi indikator teknikal (MACD, RSI, Moving Average) bergradasi oren-merah.",
      componentVibe: "Modul tabular terstruktur, badge sinyal Buy/Sell dengan presisi geometris tinggi, dan pill status transparan."
    },
    files: {
      iconPng: "/logos/sera-concept-2-quantum-candlestick-icon.png",
      iconPng1024: "/logos/sera-concept-2-quantum-candlestick-icon-1024.png",
      iconWebp: "/logos/sera-concept-2-quantum-candlestick-icon.webp",
      iconWebp1024: "/logos/sera-concept-2-quantum-candlestick-icon-1024.webp",
      transPng: "/logos/sera-concept-2-quantum-candlestick-trans.png",
      transWebp: "/logos/sera-concept-2-quantum-candlestick-trans.webp",
      fullPng: "/logos/sera-concept-2-quantum-candlestick-full.png",
      fullWebp: "/logos/sera-concept-2-quantum-candlestick-full.webp",
      iconSvg: "/logos/sera-concept-2-quantum-candlestick-icon.svg",
      fullSvg: "/logos/sera-concept-2-quantum-candlestick-full.svg"
    }
  },
  {
    id: 3,
    slug: "sera-concept-3-phoenix-crest",
    name: "The Continuum S",
    tagline: "Monoline Continuum & Compounding Loop",
    coreMetaphor: "Lengkungan Monoline Kontinu + Simbol Perputaran Modal Berkelanjutan",
    badge: "Monoline & Elegan",
    palette: {
      black: { name: "Carbon Minimal", hex: "#111116", role: "Ketenangan eksekutif, kanvas bebas distraksi" },
      orange: { name: "Luminous Amber", hex: "#FFA600", role: "Kelanjutan profit, pertumbuhan modal yang berkelanjutan" },
      red: { name: "Foundation Crimson", hex: "#E11D48", role: "Daya tahan modal, disiplin investasi jangka panjang" }
    },
    philosophy: {
      visualShape:
        "Sebuah garis kurva tunggal kontinu (monoline ribbon stroke) berkesinambungan dengan ketebalan proporsional geometris yang membentuk huruf 'S' mulus tanpa sudut kasar. Dilengkapi satu titik simpul (pulse dot) minimalis di ujung kurva atas sebagai representasi fokus kecerdasan buatan.",
      colors:
        "Aliran transisi warna mulus tanpa jeda dari Merah Kirmizi (#E11D48) melalui Oranye Neon (#FF5100) hingga Kuning Amber (#FFA600). Garis kontinu ini mengalir tenang di atas kanvas Hitam Matte (#111116) yang mewah.",
      aiAndStockSynergy:
        "Menyimbolkan prinsip 'The Power of Compounding' dalam investasi saham. Huruf S yang mengalir seperti simbol infinity melambangkan siklus modal yang terus berputar, bertumbuh, dan berkembang biak secara cerdas melalui asistensi SERA AI.",
      relevanceToIndonesianMarket:
        "Sangat relevan untuk mengubah pola pikir investor Indonesia dari sekadar spekulasi jangka pendek menjadi pembentukan kekayaan jangka panjang (wealth accumulation) yang tenang, percaya diri, dan berkelas institusional."
    },
    uiuxImpact: {
      primaryAtmosphere: "Modern Luxury Fintech ala Revolut atau Apple Wallet dengan lengkungan halus (rounded-2xl) dan breathing room luas.",
      accentUsage: "Glow lembut pada kartu portofolio dan pill filter saham; gradasi oranye-merah halus pada progress ring dan chart area.",
      componentVibe: "Elegan, ramah pengguna, kartu bertransisi lembut, dan tipografi bersahabat."
    },
    files: {
      iconPng: "/logos/sera-concept-3-phoenix-crest-icon.png",
      iconPng1024: "/logos/sera-concept-3-phoenix-crest-icon-1024.png",
      iconWebp: "/logos/sera-concept-3-phoenix-crest-icon.webp",
      iconWebp1024: "/logos/sera-concept-3-phoenix-crest-icon-1024.webp",
      transPng: "/logos/sera-concept-3-phoenix-crest-trans.png",
      transWebp: "/logos/sera-concept-3-phoenix-crest-trans.webp",
      fullPng: "/logos/sera-concept-3-phoenix-crest-full.png",
      fullWebp: "/logos/sera-concept-3-phoenix-crest-full.webp",
      iconSvg: "/logos/sera-concept-3-phoenix-crest-icon.svg",
      fullSvg: "/logos/sera-concept-3-phoenix-crest-full.svg"
    }
  }
];

export default function LogoShowcasePage() {
  const [selectedConceptId, setSelectedConceptId] = useState<number>(1);
  const [activeAppliedId, setActiveAppliedId] = useState<number | null>(null);
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState<"card" | "header" | "mobile">("card");

  // Fetch current active logo on mount
  useEffect(() => {
    fetch("/api/set-active-logo")
      .then((res) => res.json())
      .then((data) => {
        if (data?.activeMeta?.activeId) {
          setActiveAppliedId(data.activeMeta.activeId);
        }
      })
      .catch(() => {});
  }, []);

  const current = CONCEPTS.find((c) => c.id === selectedConceptId) || CONCEPTS[0];

  const handleApplyLogo = async (conceptId: number) => {
    setIsApplying(true);
    setNotification(null);
    try {
      const res = await fetch("/api/set-active-logo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conceptId })
      });
      const data = await res.json();
      if (res.ok) {
        setActiveAppliedId(conceptId);
        setNotification(`Sukses! Logo Konsep ${conceptId} telah dipasang ke folder web (/public/logo-trans.webp & logo-full.png) dan aktif di Header.`);
      } else {
        setNotification(`Gagal: ${data.error || "Terjadi kesalahan"}`);
      }
    } catch {
      setNotification("Gagal menghubungi server endpoint.");
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080b] text-slate-100 font-sans selection:bg-[#ff5100]/30 selection:text-white pb-24">
      {/* Background radial atmosphere */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#ff3b00]/10 rounded-full blur-[120px]" />
        <div className="absolute top-1/3 -right-40 w-[30rem] h-[30rem] bg-[#e11d48]/10 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 left-1/4 w-80 h-80 bg-[#ff8400]/08 rounded-full blur-[100px]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
      </div>

      {/* Top Floating Navigation */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-[#090a0f]/80 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link
              href="/"
              className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 transition-colors text-slate-300 hover:text-white"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Kembali ke Chat SERA
            </Link>
            <span className="text-white/20">|</span>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-gradient-to-r from-[#ff5100]/20 to-[#e11d48]/20 text-[#ff8400] border border-[#ff5100]/30">
                <Sparkles className="w-3 h-3 text-[#ff5100]" />
                Brand Identity Suite
              </span>
              <span className="text-xs text-slate-400 font-medium hidden sm:inline">
                Sera • AI Saham Indonesia
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeAppliedId && (
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Aktif di Web: <strong>Konsep {activeAppliedId}</strong></span>
              </div>
            )}
            <button
              onClick={() => handleApplyLogo(selectedConceptId)}
              disabled={isApplying || activeAppliedId === selectedConceptId}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-lg ${
                activeAppliedId === selectedConceptId
                  ? "bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 cursor-default"
                  : "bg-gradient-to-r from-[#ff5100] via-[#ff334b] to-[#e11d48] text-white hover:opacity-90 shadow-[#ff5100]/20 hover:scale-[1.02]"
              }`}
            >
              {activeAppliedId === selectedConceptId ? (
                <>
                  <Check className="w-4 h-4" />
                  Logo Ini Sedang Aktif di Web
                </>
              ) : isApplying ? (
                "Menerapkan..."
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Pilih & Terapkan Konsep {selectedConceptId}
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Header */}
      <section className="relative z-10 pt-10 pb-6 max-w-7xl mx-auto px-4 sm:px-6">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-[#ff7700] uppercase mb-2">
            <Flame className="w-4 h-4" />
            Palet Warna: Hitam • Oren • Merah
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white mb-3">
            Eksplorasi Logo & Brand SERA
          </h1>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            Pilih di antara 3 konsep logo identitas untuk <strong>SERA (AI Saham Indonesia)</strong>. Setiap konsep dirancang dengan filosofi visual mendalam, kaitan erat dengan psikologi pasar saham Indonesia, dan langsung siap unduh dalam format <strong>PNG, WebP, dan SVG</strong> beresolusi tinggi.
          </p>
        </div>

        {/* Success Alert Banner */}
        {notification && (
          <div className="mt-6 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-sm flex items-center justify-between animate-in fade-in slide-in-from-top duration-300">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{notification}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-xs text-emerald-400 hover:underline ml-4"
            >
              Tutup
            </button>
          </div>
        )}

        {/* 3 Concept Switcher Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-8">
          {CONCEPTS.map((concept) => {
            const isSelected = selectedConceptId === concept.id;
            const isLive = activeAppliedId === concept.id;
            return (
              <button
                key={concept.id}
                onClick={() => setSelectedConceptId(concept.id)}
                className={`relative p-4 rounded-2xl border text-left transition-all duration-200 group ${
                  isSelected
                    ? "bg-[#14151f] border-[#ff5100] ring-1 ring-[#ff5100] shadow-xl shadow-[#ff5100]/10"
                    : "bg-[#0d0e14]/70 border-white/10 hover:border-white/20 hover:bg-[#12131b]"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl overflow-hidden bg-black/40 border border-white/10 flex items-center justify-center p-1.5 shrink-0">
                      <img
                        src={concept.files.iconPng}
                        alt={concept.name}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                        Konsep 0{concept.id}
                      </span>
                      <h3 className="text-base font-bold text-white group-hover:text-[#ff8400] transition-colors leading-snug">
                        {concept.name}
                      </h3>
                    </div>
                  </div>
                  {isLive && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Aktif
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  {concept.coreMetaphor}
                </p>

                <div className="flex items-center justify-between text-[11px]">
                  <span className="inline-flex items-center gap-1 font-semibold text-slate-300">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: concept.palette.orange.hex }} />
                    {concept.badge}
                  </span>
                  <span className="text-[#ff7700] flex items-center gap-1 group-hover:translate-x-0.5 transition-transform font-bold">
                    Lihat Detail <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Focus Detail Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-4 space-y-12">
        {/* Concept Spotlight Card */}
        <div className="bg-[#0e0f16] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          {/* Subtle accent glow */}
          <div 
            className="absolute top-0 right-0 w-96 h-96 rounded-full blur-[120px] pointer-events-none opacity-20"
            style={{ backgroundColor: current.palette.orange.hex }}
          />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Visual Showcase (Left Column - 5 cols) */}
            <div className="lg:col-span-5 space-y-5">
              {/* Main Visual Box */}
              <div className="relative rounded-2xl bg-gradient-to-b from-[#181924] to-[#0d0e15] border border-white/10 p-6 flex flex-col items-center justify-center min-h-[340px] group shadow-inner">
                {/* View switcher pill */}
                <div className="absolute top-3.5 right-3.5 flex items-center gap-1 bg-black/60 backdrop-blur-md p-1 rounded-xl border border-white/10 text-[10px]">
                  <button
                    onClick={() => setPreviewMode("card")}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors ${
                      previewMode === "card" ? "bg-white/20 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    Logo Mark
                  </button>
                  <button
                    onClick={() => setPreviewMode("header")}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors ${
                      previewMode === "header" ? "bg-white/20 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    Header Mock
                  </button>
                  <button
                    onClick={() => setPreviewMode("mobile")}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors ${
                      previewMode === "mobile" ? "bg-white/20 text-white" : "text-slate-400 hover:text-white"
                    }`}
                  >
                    App Icon
                  </button>
                </div>

                {previewMode === "card" && (
                  <div className="w-full flex flex-col items-center justify-center py-4 space-y-6">
                    <div className="relative w-44 h-44 sm:w-52 sm:h-52 drop-shadow-[0_16px_32px_rgba(255,80,0,0.25)] transition-transform duration-300 group-hover:scale-105">
                      <img
                        src={current.files.iconPng1024}
                        alt={`${current.name} Icon`}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="text-center">
                      <h4 className="text-xl font-black tracking-tight text-white">SERA</h4>
                      <p className="text-[11px] font-bold tracking-widest text-[#ff8400] uppercase">
                        AI SAHAM INDONESIA
                      </p>
                    </div>
                  </div>
                )}

                {previewMode === "header" && (
                  <div className="w-full py-4 space-y-4">
                    <p className="text-[11px] font-bold text-slate-400 text-center uppercase tracking-wider">
                      Simulasi Tampilan Header Navbar
                    </p>
                    <div className="rounded-xl bg-[#090a10] border border-white/15 p-3 flex items-center justify-between shadow-lg">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={current.files.iconPng}
                          alt="Sera Logo"
                          className="w-8 h-8 rounded-lg object-contain shadow-md"
                        />
                        <div>
                          <span className="text-sm font-black text-white leading-none block">Sera</span>
                          <span className="text-[9px] font-semibold text-[#ff8400] leading-none">AI Saham Indonesia</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-slate-300 font-medium border border-white/5">
                          IHSG: 7,421.3 (+0.84%)
                        </span>
                        <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-[10px] text-white">
                          BW
                        </div>
                      </div>
                    </div>

                    <div className="rounded-xl bg-[#13141f] border border-white/10 p-3.5 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Activity className="w-3.5 h-3.5 text-[#ff8400]" />
                          Sinyal AI Sera Hari Ini
                        </span>
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                          BULLISH
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        Akumulasi saham perbankan & energi terdeteksi dengan inflow institusi domestik yang kuat.
                      </p>
                    </div>
                  </div>
                )}

                {previewMode === "mobile" && (
                  <div className="w-full flex flex-col items-center justify-center py-6 space-y-4">
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Simulasi Icon Aplikasi Mobile (iOS / Android)
                    </p>
                    <div className="w-24 h-24 rounded-[26px] bg-black shadow-2xl border border-white/20 p-2 overflow-hidden shadow-[#ff5100]/20">
                      <img
                        src={current.files.iconPng}
                        alt="App Icon"
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <span className="text-xs font-semibold text-slate-300">SERA AI</span>
                  </div>
                )}
              </div>

              {/* Full Horizontal Logo Preview Box */}
              <div className="rounded-2xl bg-[#090a10] border border-white/10 p-4 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Full Horizontal Brandmark (1200 x 400)
                </span>
                <div className="rounded-xl overflow-hidden border border-white/10 bg-black/40">
                  <img
                    src={current.files.fullPng}
                    alt={`${current.name} Full Brand`}
                    className="w-full h-auto object-contain hover:scale-[1.01] transition-transform"
                  />
                </div>
              </div>

              {/* Transparent Mark Tester (Checkerboard background) */}
              <div className="rounded-2xl bg-[#0d0e14] border border-white/10 p-4 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Varian Transparan (Tanpa Background Box)
                </span>
                <div 
                  className="rounded-xl p-4 flex items-center justify-center h-28 border border-white/10"
                  style={{
                    backgroundImage: "radial-gradient(#ffffff15 1px, transparent 1px)",
                    backgroundSize: "12px 12px"
                  }}
                >
                  <img
                    src={current.files.transPng}
                    alt="Transparent Logo"
                    className="h-20 object-contain drop-shadow-md"
                  />
                </div>
              </div>

              {/* Quick Action Buttons */}
              <div className="pt-2">
                <button
                  onClick={() => handleApplyLogo(current.id)}
                  disabled={isApplying || activeAppliedId === current.id}
                  className={`w-full py-3.5 px-5 rounded-2xl font-bold text-sm transition-all shadow-xl flex items-center justify-center gap-2 ${
                    activeAppliedId === current.id
                      ? "bg-emerald-600/30 text-emerald-300 border border-emerald-500/40"
                      : "bg-gradient-to-r from-[#ff5100] via-[#ff3b30] to-[#e11d48] text-white hover:opacity-95 shadow-[#ff5100]/25 hover:scale-[1.01]"
                  }`}
                >
                  {activeAppliedId === current.id ? (
                    <>
                      <Check className="w-4 h-4" />
                      Logo Ini Sedang Aktif di Web (/public/logo-trans.webp)
                    </>
                  ) : isApplying ? (
                    "Sedang Memproses..."
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      Pilih & Terapkan Konsep {current.id} ke Web
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Comprehensive Philosophy & Relevance Breakdown (Right Column - 7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              {/* Header Title */}
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#ff5100]/20 text-[#ff8400] border border-[#ff5100]/30">
                    Konsep 0{current.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-400">• {current.badge}</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {current.name}
                </h2>
                <p className="text-sm font-semibold text-[#ff8400] mt-0.5">
                  {current.tagline}
                </p>
              </div>

              {/* 3 Core Color Swatches */}
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-[#ff8400]" />
                    Palet Warna Utama: Hitam • Oren • Merah
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Black */}
                  <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex items-center gap-3">
                    <div 
                      className="w-7 h-7 rounded-lg border border-white/20 shrink-0"
                      style={{ backgroundColor: current.palette.black.hex }}
                    />
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-white block truncate">{current.palette.black.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono block">{current.palette.black.hex}</span>
                    </div>
                  </div>
                  {/* Orange */}
                  <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex items-center gap-3">
                    <div 
                      className="w-7 h-7 rounded-lg border border-white/20 shrink-0 shadow-[0_0_12px_rgba(255,130,0,0.5)]"
                      style={{ backgroundColor: current.palette.orange.hex }}
                    />
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-white block truncate">{current.palette.orange.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono block">{current.palette.orange.hex}</span>
                    </div>
                  </div>
                  {/* Red */}
                  <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex items-center gap-3">
                    <div 
                      className="w-7 h-7 rounded-lg border border-white/20 shrink-0 shadow-[0_0_12px_rgba(225,29,72,0.4)]"
                      style={{ backgroundColor: current.palette.red.hex }}
                    />
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-white block truncate">{current.palette.red.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono block">{current.palette.red.hex}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Philosophy Accordion / Cards */}
              <div className="space-y-3.5">
                {/* 1. Bentuk Visual */}
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#ff9500]">
                    <Layers className="w-4 h-4" />
                    1. Makna Bentuk Visual (Geometric & Shape Language)
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {current.philosophy.visualShape}
                  </p>
                </div>

                {/* 2. Filosofi Warna */}
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#ff5100]">
                    <Palette className="w-4 h-4" />
                    2. Filosofi Warna (Hitam Obsidian, Oranye Neon, Merah Kirmizi)
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {current.philosophy.colors}
                  </p>
                </div>

                {/* 3. Sinergi AI & Saham */}
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#ff334b]">
                    <Cpu className="w-4 h-4" />
                    3. Kenapa Sangat Relevan untuk AI Saham
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {current.philosophy.aiAndStockSynergy}
                  </p>
                </div>

                {/* 4. Relevansi Pasar Indonesia */}
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-1.5">
                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                    <TrendingUp className="w-4 h-4" />
                    4. Konteks Spesifik Pasar Saham Indonesia (IHSG / BEI)
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {current.philosophy.relevanceToIndonesianMarket}
                  </p>
                </div>

                {/* 5. Dampak terhadap UI/UX Web ke Depan */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#12131f] to-[#0c0d13] border border-[#ff5100]/30 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-white">
                    <Laptop className="w-4 h-4 text-[#ff8400]" />
                    Dampak Terhadap Desain UI/UX Web ke Depan
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                    <li><strong className="text-white">Atmosfer Utama:</strong> {current.uiuxImpact.primaryAtmosphere}</li>
                    <li><strong className="text-white">Aturan Aksen:</strong> {current.uiuxImpact.accentUsage}</li>
                    <li><strong className="text-white">Karakter Komponen:</strong> {current.uiuxImpact.componentVibe}</li>
                  </ul>
                </div>
              </div>

              {/* Download Package Center */}
              <div className="p-5 rounded-2xl bg-[#090a10] border border-white/15 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Download className="w-4 h-4 text-[#ff8400]" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Pusat Unduhan Aset (PNG, WebP & SVG)
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">Resolusi Siap Produksi</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {/* PNG Icon 512 */}
                  <a
                    href={current.files.iconPng}
                    download={`${current.slug}-icon-512.png`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">PNG Icon</span>
                    <span className="text-[10px] text-slate-400 block">512 x 512</span>
                  </a>

                  {/* PNG Icon 1024 */}
                  <a
                    href={current.files.iconPng1024}
                    download={`${current.slug}-icon-1024.png`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">PNG Hi-Res</span>
                    <span className="text-[10px] text-slate-400 block">1024 x 1024</span>
                  </a>

                  {/* WebP Icon */}
                  <a
                    href={current.files.iconWebp}
                    download={`${current.slug}-icon-512.webp`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">WebP Icon</span>
                    <span className="text-[10px] text-slate-400 block">Modern Web</span>
                  </a>

                  {/* WebP 1024 */}
                  <a
                    href={current.files.iconWebp1024}
                    download={`${current.slug}-icon-1024.webp`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">WebP Hi-Res</span>
                    <span className="text-[10px] text-slate-400 block">1024 x 1024</span>
                  </a>

                  {/* Transparent PNG */}
                  <a
                    href={current.files.transPng}
                    download={`${current.slug}-transparent.png`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">PNG Transparan</span>
                    <span className="text-[10px] text-slate-400 block">Tanpa Box</span>
                  </a>

                  {/* Transparent WebP */}
                  <a
                    href={current.files.transWebp}
                    download={`${current.slug}-transparent.webp`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">WebP Transparan</span>
                    <span className="text-[10px] text-slate-400 block">Tanpa Box</span>
                  </a>

                  {/* Full Horizontal PNG */}
                  <a
                    href={current.files.fullPng}
                    download={`${current.slug}-full-1200x400.png`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">Full Banner PNG</span>
                    <span className="text-[10px] text-slate-400 block">1200 x 400</span>
                  </a>

                  {/* Master Vector SVG */}
                  <a
                    href={current.files.iconSvg}
                    download={`${current.slug}-master.svg`}
                    className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-center transition-colors group"
                  >
                    <span className="text-[11px] font-bold text-white block group-hover:text-[#ff8400]">Master Vector</span>
                    <span className="text-[10px] text-slate-400 block">SVG Scalable</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Comparison Matrix Table */}
        <section className="bg-[#0e0f16] border border-white/10 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-bold text-[#ff8400] uppercase tracking-wider block">
              Panduan Pemilihan
            </span>
            <h3 className="text-2xl font-black text-white tracking-tight mt-1">
              Matriks Perbandingan 3 Konsep Logo
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Ringkasan perbandingan untuk membantu Anda menentukan arah brand SERA yang paling sesuai dengan visi produk.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-slate-400">
                  <th className="py-3 px-4 font-bold uppercase tracking-wider w-1/4">Parameter</th>
                  <th className="py-3 px-4 font-bold text-white">Konsep 1: The Quantum Continuum (Fusion 2 & 3)</th>
                  <th className="py-3 px-4 font-bold text-white">Konsep 2: The Quantum Candlestick</th>
                  <th className="py-3 px-4 font-bold text-white">Konsep 3: The Continuum S (Monoline)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-400">Arketipe Brand</td>
                  <td className="py-3 px-4 font-medium text-white">The Quantitative Architect (Candlestick + AI Flow)</td>
                  <td className="py-3 px-4 font-medium text-white">The Sage & Guardian (Kuantitatif)</td>
                  <td className="py-3 px-4 font-medium text-white">The Architect (Compounding Wealth)</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-400">Target Audiens</td>
                  <td className="py-3 px-4">Trader & Investor yang butuh candlestick presisi & kemudahan AI</td>
                  <td className="py-3 px-4">Technical Analyst, Chartist, Quant Researcher</td>
                  <td className="py-3 px-4">Investor Jangka Panjang, Eksekutif, Wealth Builder</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-400">Daya Tarik Visual</td>
                  <td className="py-3 px-4">Pilar candlestick otentik bersumbu yang menyatu dalam kurva S</td>
                  <td className="py-3 px-4">Batang grafik dan perisai heksagonal yang rapi</td>
                  <td className="py-3 px-4">Lengkungan monoline kontinu yang mulus & tenang</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-400">Arah UI/UX</td>
                  <td className="py-3 px-4">Modern Quantitative Cockpit & Fluid Minimalist Fintech</td>
                  <td className="py-3 px-4">Financial Terminal dengan kepadatan data tinggi</td>
                  <td className="py-3 px-4">Luxury Fintech (Revolut/Apple) dengan transisi mulus</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-bold text-slate-400">Aksi Cepat</td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleApplyLogo(1)}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-[#ff5100] text-white font-bold transition-colors"
                    >
                      Pilih Konsep 1
                    </button>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleApplyLogo(2)}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-[#ff5100] text-white font-bold transition-colors"
                    >
                      Pilih Konsep 2
                    </button>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleApplyLogo(3)}
                      className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-[#ff5100] text-white font-bold transition-colors"
                    >
                      Pilih Konsep 3
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}
