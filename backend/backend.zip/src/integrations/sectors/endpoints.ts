import { cacheGet, cacheSet } from "./cache";
import { normalizeSymbol, sectorsGet, SectorsError } from "./client";
import type { Json } from "./types";

export const REPORT_SECTIONS = [
  "overview",
  "valuation",
  "future",
  "peers",
  "financials",
  "dividend",
  "management",
  "ownership",
] as const;
export type ReportSection = (typeof REPORT_SECTIONS)[number];

const REPORT_TTL = 6 * 3600; // 6 jam
const QUARTERLY_TTL = 12 * 3600; // 12 jam
const SCREENER_TTL = 3 * 3600; // 3 jam

/**
 * GET /v2/company/report/{symbol}/  (1 kredit per section)
 * Cache dilakukan PER SECTION: kalau BBCA/overview sudah ada, hanya section
 * yang belum ada yang diminta ke API.
 */
export async function getCompanyReport(symbol: string, sections: ReportSection[]): Promise<Json> {
  const sym = normalizeSymbol(symbol);
  const wanted = [...new Set(sections)].sort();
  const out: Json = { symbol: `${sym}.JK` };
  const missing: ReportSection[] = [];

  for (const s of wanted) {
    const hit = await cacheGet<{ value: unknown; company_name?: string }>(`report:${sym}:${s}`);
    if (hit) {
      out[s] = hit.value;
      if (hit.company_name) out.company_name = hit.company_name;
    } else {
      missing.push(s);
    }
  }

  if (missing.length) {
    const data = await sectorsGet<Json>(
      `/v2/company/report/${sym}/`,
      { sections: missing.join(",") },
      { cost: missing.length },
    );
    if (data.company_name) out.company_name = data.company_name;
    for (const s of missing) {
      out[s] = data[s] ?? null;
      await cacheSet(`report:${sym}:${s}`, { value: data[s] ?? null, company_name: data.company_name }, REPORT_TTL);
    }
  }
  return out;
}

/**
 * GET /v2/financials/quarterly/{symbol}/  (1 kredit PER KUARTAL yang dikembalikan)
 * n_quarters selalu dikirim dan dibatasi 1..8, supaya tidak pernah menarik semua kuartal.
 */
export async function getQuarterly(symbol: string, nQuarters = 4): Promise<Json[]> {
  const sym = normalizeSymbol(symbol);
  const n = Math.min(Math.max(Math.trunc(nQuarters) || 4, 1), 8);
  return sectorsGet<Json[]>(
    `/v2/financials/quarterly/${sym}/`,
    { n_quarters: n },
    { cost: n, ttlSeconds: QUARTERLY_TTL },
  );
}

/**
 * GET /v2/companies/  (1 kredit untuk where/order_by, 3 kredit untuk q bahasa natural)
 * Utamakan `where` (murah, dan kita yang mengendalikan filternya).
 */
export async function screenCompanies(args: {
  where?: string;
  orderBy?: string;
  q?: string;
  limit?: number;
}): Promise<Json> {
  const limit = Math.min(Math.max(Math.trunc(args.limit ?? 10) || 10, 1), 20);
  if (args.where) {
    return sectorsGet<Json>(
      "/v2/companies/",
      {
        where: args.where,
        order_by: args.orderBy ?? "-market_cap",
        limit,
        include_query_values: true,
      },
      { cost: 1, ttlSeconds: SCREENER_TTL },
    );
  }
  if (args.q) {
    return sectorsGet<Json>(
      "/v2/companies/",
      { q: args.q, include_query_values: true },
      { cost: 3, ttlSeconds: SCREENER_TTL },
    );
  }
  throw new SectorsError(400, "Isi `where` (disarankan) atau `q`.");
}
