export const DISCLAIMER = "Informasi dan analisis, bukan saran investasi.";

const ADVICE_PATTERNS: RegExp[] = [
  /\b(sebaiknya|disarankan|saya sarankan|rekomendasi(?:kan)?)\b.{0,40}\b(beli|jual|tahan|akumulasi)\b/i,
  /\b(beli|jual)\s+(sekarang|saja|segera)\b/i,
  /\bwajib\s+(beli|jual)\b/i,
  /\b(pasti|dijamin)\s+(naik|untung|cuan)\b/i,
];

/** Pemeriksa pasca-jawaban: mengembalikan potongan teks yang terdengar seperti saran investasi. */
export function findAdviceViolations(text: string): string[] {
  const hits: string[] = [];
  for (const re of ADVICE_PATTERNS) {
    const m = text.match(re);
    if (m) hits.push(m[0]);
  }
  return hits;
}
