import { streamText, convertToModelMessages, stepCountIs, type UIMessage, type LanguageModel } from "ai";
import { tools } from "./tools";
import { buildSystemPrompt } from "./prompts";
import { extractSessionCompanies } from "./session";
import { findAdviceViolations } from "./guardrail";
import { creditsSpent } from "../integrations/sectors/client";

/** Inti agent: satu fungsi, model bisa diganti (Gemini di produksi, model tiruan di tes). */
export async function runAgent(opts: {
  model: LanguageModel;
  messages: UIMessage[];
  level?: "simple" | "detail";
  /** hentikan model + tool kalau user menutup koneksi (hemat kredit) */
  abortSignal?: AbortSignal;
}) {
  const companies = extractSessionCompanies(opts.messages);

  return streamText({
    model: opts.model,
    system: buildSystemPrompt({ level: opts.level, companies }),
    messages: await convertToModelMessages(opts.messages),
    tools,
    abortSignal: opts.abortSignal,
    temperature: 0, // Jawaban lebih cepat dan deterministik
    maxRetries: 2,
    stopWhen: stepCountIs(5), // Turunkan dari 6 ke 5 untuk mempercepat jika terlalu lama mencari
    onFinish: (event) => {
      const violations = findAdviceViolations(event.text ?? "");
      if (violations.length) console.warn("[guardrail] terdeteksi bahasa saran investasi:", violations);
      console.log(`[credits] total terpakai sejak server nyala: ${creditsSpent()}`);
    },
  });
}
